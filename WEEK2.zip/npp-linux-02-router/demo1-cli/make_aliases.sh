alias lan1="docker exec -it  clab-mod2-play-lan1"
alias lan2="docker exec -it  clab-mod2-play-lan2"
alias lan3="docker exec -it  clab-mod2-play-lan3"
alias rtr="docker exec -it  clab-mod2-play-rtr"


