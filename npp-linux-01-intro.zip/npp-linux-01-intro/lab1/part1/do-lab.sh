#!/usr/bin/bash

# INCLUDE ALL COMMANDS NEEDED TO PERFORM THE LAB
# This file will get called from capture_submission.sh

#mkdir lab-host1
#mkdir lab-host2
#mkdir lab-host3
#mkdir lab-host4
#mkdir lab-switch



#source provided/make_aliases.sh
chmod +x ./provided/make_aliases.sh
./provided/make_aliases.sh


docker exec clab-lab1-part1-switch   ip link add name mybridge type bridge
docker exec clab-lab1-part1-switch   ip link set mybridge up
docker exec clab-lab1-part1-switch   ip link set eth1 master mybridge
docker exec clab-lab1-part1-switch   ip link set eth2 master mybridge
docker exec clab-lab1-part1-switch   ip link set eth3 master mybridge
docker exec clab-lab1-part1-switch   ip link set eth4 master mybridge




