alias sw="docker exec -it clab-lab1-part1-switch"
alias host1="docker exec -it clab-lab1-part1-host1"
alias host2="docker exec -it clab-lab1-part1-host2"
alias host3="docker exec -it clab-lab1-part1-host3"
alias host4="docker exec -it clab-lab1-part1-host4"



