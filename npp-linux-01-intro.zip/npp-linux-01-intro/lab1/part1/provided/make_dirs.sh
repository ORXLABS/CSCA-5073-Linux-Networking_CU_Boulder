mkdir lab-host1
mkdir lab-host2
mkdir lab-host3
mkdir lab-host4
mkdir lab-switch
