alias sw="docker exec -it clab-mod1-devconfig-switch"
alias h1="docker exec -it clab-mod1-devconfig-host1"
alias h2="docker exec -it clab-mod1-devconfig-host2"



