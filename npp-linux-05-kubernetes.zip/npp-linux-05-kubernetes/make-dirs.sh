#!/bin/bash

mkdir tmp

mkdir tmp/c

mkdir tmp/w1

mkdir tmp/w2

mkdir tmp/cp


