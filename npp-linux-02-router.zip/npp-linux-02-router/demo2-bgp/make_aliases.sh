alias lan1="docker exec -it  clab-mod2-bgp-lan1"
alias lan2="docker exec -it  clab-mod2-bgp-lan2"
alias rtrA="docker exec -it  clab-mod2-bgp-rtrA"
alias rtrB="docker exec -it  clab-mod2-bgp-rtrB"
alias rtrC="docker exec -it  clab-mod2-bgp-rtrC"
alias rtrD="docker exec -it  clab-mod2-bgp-rtrD"


