alias ext1="docker exec -it  clab-mod3-2ext2int-ext1"
alias ext2="docker exec -it  clab-mod3-2ext2int-ext2"
alias int1="docker exec -it  clab-mod3-2ext2int-int1"
alias int2="docker exec -it  clab-mod3-2ext2int-int2"
alias gw="docker exec -it  clab-mod3-2ext2int-gw"


